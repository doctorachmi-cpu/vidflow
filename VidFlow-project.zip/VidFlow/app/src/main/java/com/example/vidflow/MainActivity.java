package com.example.vidflow;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    LinearLayout root;
    WebView webView;
    EditText address;
    SharedPreferences prefs;

    String[] names = {
        "Instagram", "YouTube", "Google",
        "Facebook", "TikTok", "Free Fire",
        "X", "Telegram", "TED", "Snapchat",
        "18+ Websites"
    };

    String[] urls = {
        "https://www.instagram.com/",
        "https://m.youtube.com/",
        "https://www.google.com/",
        "https://m.facebook.com/",
        "https://www.tiktok.com/",
        "https://ff.garena.com/",
        "https://x.com/",
        "https://web.telegram.org/",
        "https://www.ted.com/",
        "https://www.snapchat.com/",
        "https://www.google.com/search?q=adult+websites"
    };

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        prefs = getSharedPreferences("VidFlowPrefs", MODE_PRIVATE);

        if (!prefs.getBoolean("adultConfirmed", false)) {
            showAgeGate();
        } else {
            showHome();
        }
    }

    private void showAgeGate() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 28, 28, 28);
        layout.setBackgroundColor(0xFF151515);

        TextView title = new TextView(this);
        title.setText("Welcome to VidFlow");
        title.setTextSize(27);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);

        TextView message = new TextView(this);
        message.setText(
            "This app contains links to age-restricted websites.\n\n" +
            "You must be 18 or older to continue."
        );
        message.setTextSize(17);
        message.setTextColor(0xFFFFFFFF);
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, 24, 0, 24);

        Button enter = new Button(this);
        enter.setText("I am 18 or older — Continue");
        enter.setOnClickListener(v -> {
            prefs.edit().putBoolean("adultConfirmed", true).apply();
            showHome();
        });

        Button exit = new Button(this);
        exit.setText("Exit");
        exit.setOnClickListener(v -> finish());

        layout.addView(title);
        layout.addView(message);
        layout.addView(enter);
        layout.addView(exit);

        setContentView(layout);
    }

    private void showHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10, 10, 10, 10);

        TextView heading = new TextView(this);
        heading.setText("VidFlow");
        heading.setTextSize(27);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        address = new EditText(this);
        address.setSingleLine(true);
        address.setHint("Enter website URL or search");
        root.addView(address);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button go = new Button(this);
        go.setText("Open");
        go.setOnClickListener(v -> openAddress());
        buttons.addView(go, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Button home = new Button(this);
        home.setText("Home");
        home.setOnClickListener(v -> {
            address.setText("");
            webView.loadUrl("about:blank");
        });
        buttons.addView(home, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        root.addView(buttons);

        // Scrollable website shortcuts (one row, built once)
        HorizontalScrollView bar = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);

        for (int i = 0; i < names.length; i++) {
            final String url = urls[i];
            Button b = new Button(this);
            b.setText(names[i]);
            b.setOnClickListener(v -> {
                address.setText(url);
                webView.loadUrl(url);
            });
            chips.addView(b);
        }
        bar.addView(chips);
        root.addView(bar);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setDownloadListener(
            (url, userAgent, contentDisposition, mimeType, length) -> {
                try {
                    DownloadManager.Request request =
                        new DownloadManager.Request(Uri.parse(url));

                    String name = URLUtil.guessFileName(
                        url, contentDisposition, mimeType);

                    request.setTitle(name);
                    request.setDescription("Downloading file");
                    request.setMimeType(mimeType);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setNotificationVisibility(
                        DownloadManager.Request
                            .VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    );

                    String cookie =
                        CookieManager.getInstance().getCookie(url);
                    if (cookie != null) {
                        request.addRequestHeader("Cookie", cookie);
                    }

                    request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS, name);

                    DownloadManager manager =
                        (DownloadManager) getSystemService(
                            Context.DOWNLOAD_SERVICE);
                    manager.enqueue(request);

                    Toast.makeText(this, "Download started",
                        Toast.LENGTH_LONG).show();

                } catch (Exception e) {
                    Toast.makeText(this, "Download failed",
                        Toast.LENGTH_LONG).show();
                }
            }
        );

        root.addView(webView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1
        ));

        setContentView(root);
    }

    private void openAddress() {
        String text = address.getText().toString().trim();
        if (text.isEmpty()) return;

        String url;
        if (text.startsWith("https://") || text.startsWith("http://")) {
            url = text;
        } else if (text.contains(".") && !text.contains(" ")) {
            url = "https://" + text;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(text);
        }

        webView.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
