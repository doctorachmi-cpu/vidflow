package com.example.vidflow

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var webView: WebView
    private lateinit var downloadManager: DownloadManager
    private val prefs by lazy { getSharedPreferences("vidflow_prefs", Context.MODE_PRIVATE) }

    private val sites = listOf(
        "Instagram" to "https://www.instagram.com/",
        "YouTube" to "https://www.youtube.com/",
        "Chrome / Google" to "https://www.google.com/",
        "Facebook" to "https://www.facebook.com/",
        "TikTok" to "https://www.tiktok.com/",
        "Free Fire" to "https://ff.garena.com/",
        "X" to "https://x.com/",
        "Telegram" to "https://web.telegram.org/",
        "TED" to "https://www.ted.com/",
        "Snapchat" to "https://www.snapchat.com/"
    )

    // Age-restricted shortcuts from the user's screenshot. Search links are used
    // for names whose official domain could not be confidently established.
    private val adultSites = listOf(
        "XVideos" to "https://www.xvideos.com/",
        "XNXX" to "https://www.xnxx.com/",
        "DesiGirl" to "https://www.google.com/search?q=DesiGirl+official+site",
        "TXXX" to "https://www.txxx.com/",
        "Pornhub" to "https://www.pornhub.com/",
        "Eporner" to "https://www.eporner.com/",
        "Porn.to" to "https://www.google.com/search?q=Porn.to+official+site",
        "XVideos Plus" to "https://www.xvideos.com/",
        "xHamster" to "https://xhamster.com/",
        "YouPorn" to "https://www.youporn.com/",
        "RedTube" to "https://www.redtube.com/",
        "Thumbzilla" to "https://www.thumbzilla.com/",
        "Luxe Video" to "https://www.google.com/search?q=Luxe+Video+official+site",
        "Pornxxx" to "https://www.google.com/search?q=Pornxxx+official+site",
        "Spankbang" to "https://spankbang.com/",
        "Noodle Magazine" to "https://www.google.com/search?q=Noodle+Magazine+official+site",
        "Tube8" to "https://www.tube8.com/"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        if (!prefs.getBoolean("age_gate_18_confirmed", false)) {
            showAgeGate()
        } else {
            showMainApp()
        }
    }

    private fun showAgeGate() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF0B1220.toInt())
        }

        val title = TextView(this).apply {
            text = "Age Restricted Content"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(0xFF4DE0C1.toInt())
        }
        root.addView(title, matchWrap())

        val message = TextView(this).apply {
            text = "You must be 18 years or older to continue to age-restricted websites. Please confirm your age. This is a self-declaration only and does not verify your identity or actual age."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 18)
        }
        root.addView(message, matchWrap())

        val confirm = Button(this).apply {
            text = "I am 18 or older — Continue"
            setOnClickListener {
                prefs.edit().putBoolean("age_gate_18_confirmed", true).apply()
                showMainApp()
            }
        }
        root.addView(confirm, matchWrap())

        val exit = Button(this).apply {
            text = "I am under 18 — Exit"
            setOnClickListener { finish() }
        }
        root.addView(exit, matchWrap())

        setContentView(root)
    }

    private fun showMainApp() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 20, 16, 16)
            setBackgroundColor(0xFF0B1220.toInt())
        }

        val title = TextView(this).apply {
            text = "VidFlow"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF4DE0C1.toInt())
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Browser • Video • Music • Downloads"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFFD1D9E6.toInt())
            setPadding(0, 4, 0, 14)
        }
        root.addView(subtitle, matchWrap())

        urlInput = EditText(this).apply {
            hint = "Paste direct video/audio URL or search web"
            setSingleLine(true)
            setPadding(12, 10, 12, 10)
            setTextColor(0xFF111827.toInt())
            setHintTextColor(0xFF64748B.toInt())
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(urlInput, matchWrap())

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Open"
            setOnClickListener { openInBrowser(urlInput.text.toString().trim()) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply {
            text = "Download"
            setOnClickListener { startDownload(urlInput.text.toString().trim()) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions, matchWrap())

        val siteTitle = TextView(this).apply {
            text = "Websites"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 4)
        }
        root.addView(siteTitle, matchWrap())

        val siteScroll = HorizontalScrollViewCompat(this)
        val siteRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, url) in sites) {
            siteRow.addView(Button(this).apply {
                text = name
                setOnClickListener { loadSite(url) }
            })
        }
        siteScroll.addView(siteRow)
        root.addView(siteScroll, matchWrap())

        val adultTitle = TextView(this).apply {
            text = "18+ Sites • Adults Only"
            textSize = 18f
            setTextColor(0xFFFF7070.toInt())
            setPadding(0, 14, 0, 4)
        }
        root.addView(adultTitle, matchWrap())

        val adultNotice = TextView(this).apply {
            text = "For adults aged 18+ only. Follow local laws and each website's age requirements."
            textSize = 12f
            setTextColor(0xFFD1D9E6.toInt())
            setPadding(0, 0, 0, 6)
        }
        root.addView(adultNotice, matchWrap())

        val adultScroll = HorizontalScrollViewCompat(this)
        val adultRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, url) in adultSites) {
            adultRow.addView(Button(this).apply {
                text = name
                setOnClickListener { loadSite(url) }
            })
        }
        adultScroll.addView(adultRow)
        root.addView(adultScroll, matchWrap())

        statusText = TextView(this).apply {
            text = "Ready. Choose a website or enter a URL."
            textSize = 12f
            setTextColor(0xFF4DE0C1.toInt())
            setPadding(0, 4, 0, 8)
        }
        root.addView(statusText, matchWrap())

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun openInBrowser(input: String) {
        if (input.isBlank()) {
            showMessage("Enter a website or search term.")
            return
        }
        val url = if (input.startsWith("http://") || input.startsWith("https://")) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            "https://www.google.com/search?q=" + Uri.encode(input)
        }
        loadSite(url)
    }

    private fun loadSite(url: String) {
        try {
            val uri = Uri.parse(url)
            if (uri.scheme != "https" && uri.scheme != "http") {
                showMessage("Only http/https websites are supported.")
                return
            }
            webView.loadUrl(url)
            statusText.text = "Opened: ${uri.host ?: url}"
        } catch (e: Exception) {
            showMessage("Could not open website.")
        }
    }

    private fun startDownload(raw: String) {
        if (raw.isBlank()) {
            showMessage("Paste a direct media-file URL first.")
            return
        }
        val uri = try { Uri.parse(raw) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            showMessage("Enter a valid http:// or https:// direct file URL.")
            return
        }
        try {
            val fileName = (uri.lastPathSegment ?: "media")
                .replace(Regex("[^A-Za-z0-9._-]"), "_")
                .take(100).ifBlank { "media.bin" }
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setDescription("Downloading with VidFlow")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val id = downloadManager.enqueue(request)
            statusText.text = "Download queued: $fileName (ID $id)"
            showMessage("Download started. Check Downloads.")
        } catch (e: Exception) {
            showMessage("Download failed: ${e.message ?: "unknown error"}")
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun matchWrap() =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}

/** Small horizontal scroll container implemented without an external library. */
private class HorizontalScrollViewCompat(context: Context) : android.widget.HorizontalScrollView(context)
