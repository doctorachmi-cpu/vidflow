# VidFlow Android App (தமிழ்)

## வசதிகள்
- உள்ளமைந்த WebView browser
- Instagram, YouTube, Google/Chrome search, Facebook, TikTok, Free Fire official site, X, Telegram Web shortcuts
- URL திறத்தல் அல்லது Google search
- நேரடி HTTP/HTTPS media-file URL-களுக்கு Android DownloadManager
- TED மற்றும் Snapchat shortcuts
- தனி “18+ Sites • Adults Only” பகுதி: XVideos, XNXX, DesiGirl, TXXX, Pornhub, Eporner, Porn.to, XVideos Plus, xHamster, YouPorn, RedTube, Thumbzilla, Luxe Video, Pornxxx, Spankbang, Noodle Magazine, Tube8
- 18+ age gate: app திறக்கும் முன் “18 அல்லது அதற்கு மேல்” என self-declaration; 18-க்கு கீழ் எனத் தேர்வு செய்தால் வெளியேறும்.

## வயது வரம்பு குறித்த குறிப்பு
இந்த gate என்பது பயனர் தாமாக வயதை உறுதிப்படுத்துவது மட்டுமே; அடையாள ஆவணச் சரிபார்ப்பு அல்லது உண்மையான வயது சரிபார்ப்பு அல்ல. சில பெயர்களுக்கு நேரடி official URL உறுதியாகத் தெரியாததால் Google search link திறக்கும். உள்ளூர் சட்டங்களையும் website-இன் விதிகளையும் பின்பற்ற வேண்டும்.

## வரம்புகள்
- சில websites WebView-ஐத் தடுக்கலாம் அல்லது அதிகாரப்பூர்வ app-ஐத் தேவைப்படுத்தலாம்.
- Download வசதி நேரடி media file URL-களுக்கே; streaming தளங்களிலிருந்து media-ஐப் பிரித்தெடுக்கவோ DRM/login/platform restrictions-ஐத் தாண்டவோ செய்யாது.
- இது source project; இங்கு APK build அல்லது device testing செய்யப்படவில்லை.

## Build
Android Studio-வில் project folder திறக்கவும்; Gradle sync முடிந்ததும் Run செய்யவும்.
APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
